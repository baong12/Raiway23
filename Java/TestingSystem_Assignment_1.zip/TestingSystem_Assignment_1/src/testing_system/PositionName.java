package testing_system;

public enum PositionName {
	DEV,
	TEST,
	SCRUM_MASTER,
	PM;
}
