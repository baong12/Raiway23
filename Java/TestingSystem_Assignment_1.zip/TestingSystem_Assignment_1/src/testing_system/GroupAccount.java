package testing_system;

import java.util.Date;

public class GroupAccount {
	public Group group;
	public Account account;
	public Date joinDate;

	public GroupAccount() {
	}
}