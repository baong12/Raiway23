package testing_system;

public class Answer {
	public int answerId;
	public String content;
	public Question question;
	public boolean isCorrect;

	public Answer() {
	}
}