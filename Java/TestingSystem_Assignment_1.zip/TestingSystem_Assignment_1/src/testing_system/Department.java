package testing_system;

public class Department {
	public int departmentId;
	public String departmentName;
	
	public Department() {
	}
}
