package testing_system;

public enum TypeName {
	ESSAY,
	MULTIPLE_CHOICE;
}
