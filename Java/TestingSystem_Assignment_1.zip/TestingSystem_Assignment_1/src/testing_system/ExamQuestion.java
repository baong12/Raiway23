package testing_system;

public class ExamQuestion {
	public Exam exam;
	public Question question;

	public ExamQuestion() {
	}
}