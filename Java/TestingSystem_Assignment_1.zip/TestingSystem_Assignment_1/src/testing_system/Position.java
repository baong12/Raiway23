package testing_system;

public class Position {
	public int positionId;
	public PositionName positionName;

	public Position() {
	}
}