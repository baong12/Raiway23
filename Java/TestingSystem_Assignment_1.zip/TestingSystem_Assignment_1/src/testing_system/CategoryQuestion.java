package testing_system;

public class CategoryQuestion {
	public int categoryId;
	public String categoryName;
	
	public CategoryQuestion() {
	}
}
