package testing_system;

public class TypeQuestion {
	public int typeId;
	public TypeName typeName;

	public TypeQuestion() {
	}
}