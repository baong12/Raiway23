package testing_system;

import java.util.Date;

public class Group {
	public int groupId;
	public String groupName;
	public Account creator;
	public Date createDate;

	public Group() {
	}
}